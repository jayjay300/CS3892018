package com.example.john.helloworld;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

//import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.helloworld.MESSAGE";
    TextView firebase_tv;


    // Write a message to the database
        ArrayList<String> myArrayList = new ArrayList<>();
        ListView listView;
      // needed?  FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebase_tv = (TextView) findViewById(R.id.firebaseText);
       // firebase_tv2 = (TextView) findViewById(R.id.textView);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");
        DatabaseReference userRef = database.getReference("user");
        //myRef.setValue("hello");



        ArrayList<String> users = new ArrayList<>();
        final ArrayAdapter<String> Arrayadapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, users);
        final ListView LISTVIEW = findViewById(R.id.LISTVIEW1);
        LISTVIEW.setAdapter(Arrayadapter);
        // Read from the database
       // ListView listView = (ListView) findViewById(R.id.LISTVIEW1);




        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
/*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();


            }
        }); */
        ChildEventListener UserChildListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                LISTVIEW.invalidateViews();
                User user = dataSnapshot.getValue(User.class);
                Arrayadapter.add(user.getFirstname().toString()+" "+user.getLastname().toString()+" "+user.getAge().toString());
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };

        userRef.addChildEventListener(UserChildListener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /** Called when the user taps the Send button */
    public void sendMessage(View view) {
      //  Intent intent = new Intent(this, DisplayMessageActivity.class);
        EditText editText = (EditText) findViewById(R.id.editText);
        EditText editText1 = (EditText) findViewById(R.id.editText3);
        EditText editText2 = (EditText) findViewById(R.id.editText4);
        String fname = editText.getText().toString();
        String lname = editText2.getText().toString();
        String age = editText1.getText().toString();
        User newuser = new User();
        newuser.writeNewUser(fname, lname, age);
      //  String value = dataSnapshot.getValue(String.class);
       // firebase_tv.setText(value);
        //intent.putExtra(EXTRA_MESSAGE, message);
      //  startActivity(intent);

    }

}
//1. Create an Android app that permits users to enter their first name, DONE
// last name and age, DONE
// and save them in Firebase via a form (with a submit button). DONE
// Your app should support 2 languages. This exercise is to learn how to submit data to firebase and how to support different languages. DONE

//  2. Create an Android app that permits users to get the list of names and ages of users in Firebase.
// It will display them on the screen. This exercise is to learn how to retrieve data from firebase.